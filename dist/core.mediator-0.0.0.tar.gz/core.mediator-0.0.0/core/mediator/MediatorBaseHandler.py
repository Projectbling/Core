from .MediatorBaseRequestModel import MediatorRequestModel


class MediatorBaseHandler:

    def handle(req:MediatorRequestModel):
        pass