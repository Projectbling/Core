

class MediatorRequestModel:
    
    pass