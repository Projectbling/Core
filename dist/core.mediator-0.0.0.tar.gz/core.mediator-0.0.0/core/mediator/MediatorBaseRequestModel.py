

class MediatorRequestModel:
    
    pass